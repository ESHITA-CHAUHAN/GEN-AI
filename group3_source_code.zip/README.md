# Text Rewriting and Grammar Assistant

A small local web application built by Group 3. It compares original text with a clear-and-concise rewrite and a formal rewrite. It also separates source statements from interpretation.

## Run the demo

Requires Python 3. No third-party packages are needed.

```bash
python3 app.py
```

Open http://127.0.0.1:8000. Without an API key, the app runs in **local demo mode** using simple cleanup rules. This demonstrates the interface but is not a large language model and may miss grammar problems or make awkward edits.

## Enable model-backed rewriting (optional)

Set environment variables in the terminal before starting the app. Do not put secrets in source files or submit them.

```bash
export OPENAI_API_KEY="your-key"
export OPENAI_MODEL="gpt-4o-mini"
export OPENAI_BASE_URL="https://api.openai.com/v1"
python3 app.py
```

The model integration uses the OpenAI-compatible Chat Completions API. Provider access, model availability, pricing and policies vary. The model prompt asks it to preserve facts and return source facts and interpretation separately. Verify every output before relying on it. For non-OpenAI providers, configure a compatible base URL, model name and key.

## Files

- `app.py` - web server, model request, local demo fallback, and interface
- `report.docx` - technical report (5–8 pages)
- `test-cases.md` - manual test plan and observed demo-mode results
- `presentation-outline.md` - 5–10 minute presentation and demo guide

## Security and privacy

The server listens only on `127.0.0.1`. API credentials are read from the environment; never commit keys. Do not submit sensitive text. API mode sends the entered text to the configured model provider.
